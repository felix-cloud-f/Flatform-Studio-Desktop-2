const { app, BrowserWindow, shell, ipcMain, clipboard } = require("electron");
const path = require("path");

function createWindow() {
  const win = new BrowserWindow({
    width: 1320, height: 880, minWidth: 420, minHeight: 600,
    title: "FlatForm Studio", backgroundColor: "#FBFBFD", autoHideMenuBar: true,
    icon: path.join(__dirname, "build", "icon.png"),
    webPreferences: { contextIsolation: true, nodeIntegration: false, preload: path.join(__dirname, "preload.js") }
  });
  win.loadFile(path.join(__dirname, "index.html"));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: "deny" }; });
  // The app is one page. Never navigate away (this also stops a dropped file from replacing the app).
  win.webContents.on("will-navigate", (e) => e.preventDefault());
}

// "Copy and paste" in the Reference image box: hand the copied image to the page, or nothing.
ipcMain.handle("read-clipboard-image", () => {
  const img = clipboard.readImage();
  return img.isEmpty() ? "" : img.toDataURL();
});

app.whenReady().then(() => {
  createWindow();
  app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
