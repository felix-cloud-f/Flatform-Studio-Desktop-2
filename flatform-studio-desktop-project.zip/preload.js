const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("ffsDesktop", {
  readClipboardImage: () => ipcRenderer.invoke("read-clipboard-image")
});
