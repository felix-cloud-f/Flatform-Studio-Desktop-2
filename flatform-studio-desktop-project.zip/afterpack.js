// macOS: give the app an ad-hoc signature so it can start on Apple Silicon without a paid developer certificate.
const { execSync } = require("child_process");
const path = require("path");
exports.default = async function (context) {
  if (context.electronPlatformName !== "darwin") return;
  const app = path.join(context.appOutDir, context.packager.appInfo.productFilename + ".app");
  try { execSync(`codesign --force --deep --sign - "${app}"`, { stdio: "inherit" }); }
  catch (e) { console.log("Ad-hoc signing skipped:", e.message); }
};
