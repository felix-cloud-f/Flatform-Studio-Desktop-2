FlatForm Studio - desktop app for Windows and macOS (Electron)

Build on GitHub (no tools needed on your computer):
1. Create a public GitHub repository and upload THIS ZIP FILE (do not unzip it).
2. Add the workflow file .github/workflows/build-desktop.yml (text is in the chat).
3. Open the Actions tab, wait for the green tick, and download the artifacts:
   FlatForm-windows-latest -> Setup .exe for Windows
   FlatForm-macos-latest   -> two .dmg files (Apple chip and Intel)

Run locally instead (needs Node.js): npm install, then npm start. Build installers with npm run dist.

Windows: if SmartScreen warns, click More info, then Run anyway.
macOS: the app is not signed. Open the .dmg, drag the app to Applications, then right-click the app and choose Open the first time.
