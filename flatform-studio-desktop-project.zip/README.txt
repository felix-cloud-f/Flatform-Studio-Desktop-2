FlatForm Studio - desktop app for Windows and macOS (Electron), version 1.2

Reference image section: Add image from files, Copy and paste (or Ctrl+V / Cmd+V), Clear image.

Build on GitHub (no tools needed on your computer):
1. Upload THIS ZIP FILE to a public GitHub repository (do not unzip it). The same name replaces the old one.
2. Add the workflow file .github/workflows/build-desktop.yml (text is in the chat).
3. Open the Actions tab, wait for the green tick, and download the artifacts:
   FlatForm-windows-latest -> Setup .exe for Windows
   FlatForm-macos-latest   -> two .dmg files (Apple chip and Intel)

Run locally instead (needs Node.js): npm install, then npm start. Build installers with npm run dist.

Windows: if SmartScreen warns, click More info, then Run anyway.
macOS: the app is not notarised. See the guide: right-click Open, or System Settings > Privacy & Security > Open Anyway.
